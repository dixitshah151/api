<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH."/libraries/REST_Controller.php";

class Api extends REST_Controller {

	function __contsruct(){
		parent::__contsruct();
	}
	public function student_get()
	{

		// $id=$this->get('id');
		$student_id=$this->uri->segment(3);
		// $student=array(
		// 	1=>array("firstname"=>"dixit","lastname"=>"shah"),
		// 	2=>array("firstname"=>"man","lastname"=>"ash")

		// );
		$this->load->model('Model_students');
		$student=$this->Model_students->get_by(array('student_id'=>$student_id, 'status'=>'1'));
		
		if(isset($student['student_id'])){
			$this->response(array("result"=>"Success","Message"=>$student));
		}
		else{
			$this->response(array("result"=>"Error","Message"=>"result not found"),REST_Controller::HTTP_NOT_FOUND);
		}
		
	}

	public function student_put(){
		
		// var_dump($this->put());
		$this->load->library('form_validation');
		$this->form_validation->set_data($this->put());
		if($this->form_validation->run('student_put') != false){
			// die('good data');
			$student = $this->put();
			$this->load->model('Model_students');
			$exists = $this->Model_students->get_by(array('email_address'=>$this->put('email_address')));
			if($exists){
			$this->response(array("result"=>"Error","Message"=>"Email Address Already Exists"),REST_Controller::HTTP_CONFL);	
			}


			$student_id =$this->Model_students->insert($student);
			if(!$student_id){
				$this->response(array("result"=>"Error","Message"=>"result not found"),REST_Controller::HTTP_INERNAL_SERVER_ERROR);
			}
			else
			{
				$this->response(array('status'=>'success','message'=>'created'));
			}
		}
		else
		{
			// die('bad data');
			$this->response(array('status'=>'failure','message'=>$this->form_validation->get_errors_as_array()),REST_Controller::HTTP_BAD_REQUEST);
		}


		
	}
}
